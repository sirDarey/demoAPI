package users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApiFidelityApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApiFidelityApplication.class, args);
	}

}
