package users.exceptions;

public class OtherExceptions extends Exception {
	public OtherExceptions(String message) {
		super(message);
	}
}
